//
//  MapViewController.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/29.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import ReactiveSwift
import ReactiveCocoa

class MapViewController: UIViewController {
    
    private let locationManager = CLLocationManager()
    private let manager = PlaceManager.shared
    private let interactor = Interactor()
    
    private var places: [Place] = []
    
    @IBOutlet private weak var mapView: MKMapView!
    @IBOutlet private weak var buttonContainerView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.requestWhenInUseAuthorization()
        
        mapView.delegate = self
        
        let trackingButton = MKUserTrackingButton(mapView: mapView)
        buttonContainerView.addSubview(trackingButton)
        
        buttonContainerView.isHidden = !CLLocationManager.locationServicesEnabled()
        
        manager.loadFromUserDefault()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        mapView.removeAnnotations(mapView.annotations)
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        reloadAnnotations()
    }
    
    @IBAction func didLongPressMapView(_ sender: UILongPressGestureRecognizer) {
        guard sender.state == .began,
            let viewController = R.storyboard.registView().instantiateInitialViewController() as? RegistViewController else {
            return
        }
        
        let coodinate = mapView.convert(sender.location(in: mapView), toCoordinateFrom: mapView)
        let place = Place(coodinate: Location(latitude: coodinate.latitude, longitude: coodinate.longitude))
        viewController.place = place
        viewController.mode = .register
        
        let navigationController = UINavigationController(rootViewController: viewController)
        
        present(navigationController, animated: true, completion: nil)
    }
    
    private func reloadAnnotations() {
        let fetchedAnnotations = manager.listPlaces()
        
        fetchedAnnotations.forEach { add(annotation: $0) }
        
        places = fetchedAnnotations
    }
    
    private func add(annotation place: Place) {
        mapView.addAnnotation(makeAnnotation(from: place))
    }
    
    private func remove(annotation place: Place) {
        let removeAnnotation = mapView.annotations.map { $0 as? PlaceMarkAnnotation }
            .compactMap { $0 }
            .filter { $0.id == place.id }
            .first
        guard let annotation = removeAnnotation else {
            return
        }
        mapView.removeAnnotation(annotation)
    }
    
    private func makeAnnotation(from place: Place) -> PlaceMarkAnnotation {
        return PlaceMarkAnnotation(coodinate: place.coodinate,
                                             id: place.id,
                                             title: place.title,
                                             subtitle: place.subTitle,
                                             color: place.color.uiColor)
    }
    
    func deselectAnnotations() {
        mapView.selectedAnnotations.forEach {
            mapView.deselectAnnotation($0, animated: true)
        }
    }
    
    func setRegionOverView() {
        let center = CLLocationCoordinate2D(latitude: 39.31221644561231, longitude: 137.68066399999995)
        let span = MKCoordinateSpan(latitudeDelta: 23.543774733422033, longitudeDelta: 16.699219719852067)
        mapView.setRegion(MKCoordinateRegion(center: center, span: span), animated: true)
    }
    
}

extension MapViewController: MKMapViewDelegate {
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        
        guard !(annotation is MKUserLocation) else {
            return nil
        }
        
        let annotationView = mapView.dequeueReusableAnnotationView(withIdentifier: MKMapViewDefaultAnnotationViewReuseIdentifier, for: annotation)
        
        guard let markerAnnotationView = annotationView as? MKMarkerAnnotationView,
            let placeMarkAnnotation = annotation as? PlaceMarkAnnotation else { return annotationView }
        
        markerAnnotationView.annotation = placeMarkAnnotation
        markerAnnotationView.markerTintColor = placeMarkAnnotation.color
        markerAnnotationView.accessibilityIdentifier = placeMarkAnnotation.id
        markerAnnotationView.animatesWhenAdded = true
        markerAnnotationView.canShowCallout = true
        markerAnnotationView.isDraggable = true
        
        if let place = places.filter({$0.id == placeMarkAnnotation.id}).first {
            let view = CalloutView(place: place)
            
            view.deleteButton.reactive.controlEvents(.touchUpInside).observeValues { [weak self] (_) in
                let alert = UIAlertController(title: "Delete Place", message: place.title, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
                alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { [weak self] (_) in
                    UIView.animate(withDuration: 0.3, animations: {
                        self?.mapView.deselectAnnotation(annotation, animated: false)
                    }, completion: { (isComplete) in
                        self?.manager.remove(placeID: place.id)
                        self?.remove(annotation: place)
                    })
                }))
                self?.present(alert, animated: true, completion: nil)
            }
            
            view.dummyButton2.reactive.controlEvents(.touchUpInside).observeValues { (_) in
                guard let semiModalView = R.storyboard.semiModalView().instantiateInitialViewController() as? SemiModalViewController else {
                    return
                }
                semiModalView.place = place
                mapView.deselectAnnotation(placeMarkAnnotation, animated: true)
                self.present(semiModalView, animated: true, completion: nil)
            }
            
            markerAnnotationView.detailCalloutAccessoryView = view
            
            markerAnnotationView.markerTintColor = place.color.uiColor
        }
        
        return markerAnnotationView
    }
}

extension MapViewController: UIViewControllerTransitioningDelegate {
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return DismissAnimator()
    }
    
    func interactionControllerForDismissal(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        return interactor.hasStarted ? interactor : nil
    }
}
