//
//  OverCurrentTransitioningInteractor.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/02/28.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class OverCurrentTransitioningInteractor: UIPercentDrivenInteractiveTransition {
    enum State {
        case none
        case shouldStart
        case hasStarted
        case shouldFinish
    }
    
    var state: State = .none
    var startInteractionTranslationY: CGFloat = 0
    var startHandler: (() -> Void)?
    var resetHandler: (() -> Void)?
    
    override func cancel() {
        completionSpeed = percentComplete
        super.cancel()
    }
    
    override func finish() {
        completionSpeed = 1.0 - percentComplete
        super.finish()
    }
    
    func setStartInteractionTranslationY(_ translationY: CGFloat) {
        switch state {
        case .shouldStart:
            startInteractionTranslationY = translationY
        default:
            break
        }
    }
    
    func updateStateShouldStartIfNeeded() {
        switch state {
        case .none:
            state = .shouldStart
            startHandler?()
        default:
            break
        }
    }
    
    func reset() {
        state = .none
        startInteractionTranslationY = 0
        resetHandler?()
    }
}
