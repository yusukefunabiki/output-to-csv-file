//
//  DetailTableViewCell.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/01.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class DetailTableViewCell: UITableViewCell {
    @IBOutlet private weak var titleLabel: UILabel!
    @IBOutlet private weak var contentsLabel: UILabel!
    
    var title: String? {
        set { titleLabel.text = newValue }
        get { return titleLabel.text }
    }
    
    var contents: String? {
        set { contentsLabel.text = newValue }
        get { return contentsLabel.text }
    }
    
    func setUpCell(with viewModel: DetailTableViewCellModel) {
        self.title = viewModel.title
        self.contents = viewModel.contents
    }
}


struct DetailTableViewCellModel {
    var title: String
    var contents: String?
    
    init(title: String, contents: String?) {
        self.title = title
        self.contents = contents
    }
}
