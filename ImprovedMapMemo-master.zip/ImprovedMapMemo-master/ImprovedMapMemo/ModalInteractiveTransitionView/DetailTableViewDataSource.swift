//
//  DetailTableViewDataSource.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/05.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import Rswift

class DetailTableViewDataSource: NSObject {
    var items: [DetailTableViewCellModel]
    let cellID: Rswift.ReuseIdentifier<DetailTableViewCell>
    
    init(place: Place, cellID: Rswift.ReuseIdentifier<DetailTableViewCell>) {
        self.items = []
        self.cellID = cellID
        
        super.init()
        
        self.updateItems(of: place)
    }
    
    func updateItems(of place: Place) {
        var ababa: [DetailTableViewCellModel] = []
        ababa.append(DetailTableViewCellModel(title: "Title", contents: place.title))
        ababa.append(DetailTableViewCellModel(title: "Subtitle", contents: place.subTitle))
        ababa.append(DetailTableViewCellModel(title: "Tel", contents: place.tel))
        ababa.append(DetailTableViewCellModel(title: "Address", contents: place.address))
        ababa.append(DetailTableViewCellModel(title: "URL", contents: place.url))
        ababa.append(DetailTableViewCellModel(title: "Memo", contents: place.memo))
        
        self.items = ababa
    }
}

extension DetailTableViewDataSource: UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID, for: indexPath)!
        cell.setUpCell(with: items[indexPath.row])
        return cell
    }
    
    
}
