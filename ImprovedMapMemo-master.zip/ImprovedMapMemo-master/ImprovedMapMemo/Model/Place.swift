//
//  Place.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/29.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import MapKit

struct Place: Codable, Hashable {
    let id: String
    var title: String {
        didSet {
            title = title.isEmpty ? "Untitled Place" : title
        }
    }
    var subTitle: String?
    var coodinate: Location
    var color: String
    var tel: String?
    var url: String?
    var memo: String?
    var address: String?
    
    init(coodinate: Location) {
        self.id = NSUUID().uuidString
        self.coodinate = coodinate
        self.color = UIColor.red.hexString
        self.title = ""
    }
}

struct Location: Codable, Hashable {
    // 経度
    let latitude: Double
    
    // 緯度
    let longitude: Double
    
    init(latitude: Double, longitude: Double) {
        self.latitude = latitude
        self.longitude = longitude
    }
}

extension Location {
    var coordinate: CLLocationCoordinate2D {
        get {
            return CLLocationCoordinate2D(latitude: self.latitude, longitude: self.longitude)
        }
    }
    
    var clLocation: CLLocation {
        get {
            return CLLocation(latitude: self.latitude, longitude: self.longitude)
        }
    }
}

extension CLLocationCoordinate2D {
    var location: Location {
        get {
            return Location(latitude: self.latitude, longitude: self.longitude)
        }
    }
    
    var clLocation: CLLocation {
        get {
            return CLLocation(latitude: self.latitude, longitude: self.longitude)
        }
    }
}


class PlaceMarkAnnotation: NSObject, MKAnnotation {
    let coordinate: CLLocationCoordinate2D
    let id: String
    let title: String?
    let subtitle: String?
    let color: UIColor
    
    init(coodinate: Location, id: String, title: String?, subtitle: String?, color: UIColor = .red) {
        self.coordinate = CLLocationCoordinate2D(latitude: coodinate.latitude, longitude: coodinate.longitude)
        self.id = id
        self.title = title
        self.subtitle = subtitle
        self.color = color
    }
    
    
}
