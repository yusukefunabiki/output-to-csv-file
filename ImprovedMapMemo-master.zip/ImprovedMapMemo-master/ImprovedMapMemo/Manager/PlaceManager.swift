//
//  PlaceManager.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/29.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation

class PlaceManager {
    static let shared = PlaceManager()
    private init() {    }
    
    private var places: [Place] = []
    private let defaults = UserDefaults.standard
    
    func register(place: Place) {
        if !places.contains(where: { $0.id == place.id }) {
            places.append(place)
            saveToUseDefaults()
        }
    }
    
    func listPlaces() -> [Place] {
        return places
    }
    
    func edit(place: Place) {
        if let index = places.firstIndex(where: { $0.id == place.id }) {
            places[index] = place
            saveToUseDefaults()
        }
    }
    
    func fetch(placeID: String) -> Place? {
        return places.filter { $0.id == placeID }.first
    }
    
    func remove(placeID: String) {
        if let index = places.firstIndex(where: { $0.id == placeID}) {
            places.remove(at: index)
            saveToUseDefaults()
        }
    }
    
    private func saveToUseDefaults() {
        let data = places.map { try? JSONEncoder().encode($0) }
        defaults.set(data, forKey: "SavedPlaces")
    }
    
    func loadFromUserDefault() {
        guard let encodedData = defaults.array(forKey: "SavedPlaces") as? [Data] else {
            return
        }
        
        places = encodedData.map { try! JSONDecoder().decode(Place.self, from: $0)}
    }
}
