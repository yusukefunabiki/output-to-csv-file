//
//  RegistViewController.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/30.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class RegistViewController: UITableViewController {
    
    private let manager = PlaceManager.shared
    var place: Place!
    var mode: EditMode = .edit
    
    @IBOutlet private weak var titleTextField: MaterialTextField!
    @IBOutlet private weak var subtitleTextField: MaterialTextField!
    @IBOutlet private weak var colorPicker: MaterialColorPickerTextField!
    @IBOutlet private weak var telTextField: MaterialTextField!
    @IBOutlet private weak var addressTextField: MaterialTextField!
    @IBOutlet private weak var urlTextField: MaterialTextField!
    @IBOutlet private weak var memoTextView: MaterialTextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.tableFooterView = UIView()
        
        titleTextField.text = place.title
        subtitleTextField.text = place.subTitle
        telTextField.text = place.tel
        urlTextField.text = place.url
        memoTextView.text = place.memo
        addressTextField.text = place.address
        colorPicker.select(colorString: place.color)
        
        titleTextField.keyboardType = .normal
        subtitleTextField.keyboardType = .normal
        telTextField.keyboardType = .tel
        addressTextField.keyboardType = .address
        urlTextField.keyboardType = .url
        
        let toolBar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 0, height: 35))
        let space = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil)
        let autofill = UIBarButtonItem(title: "Autofill", style: .plain, target: self, action: #selector(autofillAddress))
        toolBar.setItems([space, autofill], animated: true)
        toolBar.backgroundColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.5)
        addressTextField.textFieldAccessoryView = toolBar
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    @IBAction func didTapDoneButton(_ sender: Any) {
        
        place.title = titleTextField.text!
        place.subTitle = subtitleTextField.text
        place.tel = telTextField.text
        place.url = urlTextField.text
        place.memo = memoTextView.text
        place.color = colorPicker.selectedColor.hexString
        place.address = addressTextField.text
        
        switch mode {
        case .edit:
            manager.edit(place: place)
        case .register:
            manager.register(place: place)

        }
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func didTapCancelButton(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc private func autofillAddress() {
        let geocoder = CLGeocoder()
        geocoder.reverseGeocodeLocation(self.place.coodinate.clLocation) { (placemarkArray, error) in
            
            if let error = error {
                print(error.localizedDescription)
                return
            }
            guard let placemark = placemarkArray?.first else {
                return
            }
            var address = ""
            if let ocean = placemark.ocean {
                address.append(ocean)
                address.append(" (\(self.place.coodinate.latitude), \(self.place.coodinate.longitude))")
            } else {
                address.append(placemark.country ?? "")
                address.append(placemark.country ?? "")
                address.append(placemark.administrativeArea ?? "")
                address.append(placemark.subAdministrativeArea ?? "")
                address.append(placemark.locality ?? "")
                address.append(placemark.thoroughfare ?? "")
                address.append(placemark.subThoroughfare ?? "")
            }
            
            self.addressTextField.text = address
        }
    }
    
    
    @objc private func done() {
        memoTextView.endEditing(true)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.tableView.endEditing(false)
    }
}

extension RegistViewController: UITextFieldDelegate, UITextViewDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}

enum EditMode {
    case edit
    case register
}
