//
//  ColorPickerView.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/13.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import ReactiveCocoa
import ReactiveSwift

class ColorPickerView: UIView {
    
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var colorView: UIView!
    @IBOutlet weak var button: UIButton!
    private var picker: UIPickerView!
    
    private let colorList = UIColor.colorList
    
    var selectedColor: UIColor {
        return colorList[picker.selectedRow(inComponent: 0)]
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNib()
        initViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadNib()
        initViews()
    }
    
    private func initViews() {
        
        button.reactive.controlEvents(.touchUpInside).observeValues { [unowned self] (_) in
            self.textField.becomeFirstResponder()
        }
        
        picker = UIPickerView()
        picker.delegate = self
        picker.dataSource = self
        
        let toolBar: UIToolbar = {
            let bar = UIToolbar(frame: CGRect(x: 0, y: 0, width: 0, height: 35))
            let doneButton = UIBarButtonItem(barButtonSystemItem: .done
                , target: self, action: #selector(pickerDone))
            let blank = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: self, action: nil)
            bar.setItems([blank, doneButton], animated: true)
            
            return bar
        }()
        
        textField.inputView = picker
        textField.inputAccessoryView = toolBar
        
        textField.tintColor = .clear
        colorView.backgroundColor = selectedColor
        
    }
    
    private func loadNib() {
        let view = R.nib.colorPickerView(owner: self)!
        view.frame = self.bounds
        self.addSubview(view)
    }
    
    @objc private func pickerDone() {
        self.endEditing(false)
    }
    
    func select(colorString hexString: String) {
        guard let index = colorList.firstIndex(where: {
            return hexString == $0.hexString
        }) else {
            return
        }
        picker.selectRow(index, inComponent: 0, animated: false)
        colorView.backgroundColor = colorList[index]
    }
}

extension ColorPickerView: UIPickerViewDelegate, UIPickerViewDataSource {
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return colorList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        let view = UIView(frame: CGRect(x: 0, y: 0, width: 60, height: 35))
        view.backgroundColor = colorList[row]
        return view
    }
    
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        self.colorView.backgroundColor = colorList[row]
    }
    
}
