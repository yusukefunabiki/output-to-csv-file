//
//  MaterialTextView.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/11.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import ReactiveSwift
import ReactiveCocoa
import Result


class MaterialTextView: MaterialContentView {
    
    private var textView: UITextView!
    
    var text: String? {
        get {
            return textView.text
        }
        set {
            textView.text = newValue
            isInputed = !(newValue?.isEmpty ?? true)
        }
    }
    
    var continuousTextValue: Signal<String?, NoError> {
        return textView.reactive.continuousTextValues
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupViews()
    }
    
    private func setupViews() {
        textView = UITextView()
        stackView.addArrangedSubview(textView)
        textView.delegate = self
    }
    
}

extension MaterialTextView: UITextViewDelegate {
    func textViewDidBeginEditing(_ textView: UITextView) {
        isInputed = true
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        isInputed = !(textView.text.isEmpty)
    }
}
