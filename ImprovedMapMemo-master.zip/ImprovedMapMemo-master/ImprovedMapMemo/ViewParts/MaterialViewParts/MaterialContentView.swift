//
//  MaterialTextField.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/06.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import ReactiveCocoa
import ReactiveSwift
import Result

class MaterialContentView: UIView {
    
    @IBOutlet fileprivate weak var titleLabel: SpacedLabel!
    @IBOutlet private weak var roundView: UIView!
    @IBOutlet weak var stackView: UIStackView!
    
    @IBInspectable
    var sideMargin: CGFloat = 8 {
        didSet { titleLabel.sideMargin = sideMargin }
    }
    @IBInspectable
    var color: UIColor = R.color.blue()!
    
    @IBInspectable
    var title: String? {
        didSet {
            titleLabel.text = title
            titleLabel.isHidden = title?.isEmpty ?? true
        }
    }
    
    var isInputed: Bool = false {
        didSet {
            titleLabel.textColor = isInputed ? color : R.color.separator()!
            roundView.borderColor = isInputed ? color : R.color.separator()!
        }
    }

    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadNib()
    }
    
    private func loadNib() {
        let view = R.nib.materialContentView(owner: self)!
        view.frame = self.bounds
        self.addSubview(view)
        
        titleLabel.textColor = R.color.separator()!
        roundView.borderColor = R.color.separator()!
    }
}
