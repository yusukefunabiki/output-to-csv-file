//
//  MaterialTextField.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/11.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import ReactiveCocoa
import ReactiveSwift
import Result
import CoreLocation


class MaterialTextField: MaterialContentView {
    
    private var textField: UITextField!
    
    var text: String? {
        get { return textField.text }
        set {
            textField.text = newValue
            isInputed = !(newValue?.isEmpty ?? true)
        }
    }
    
    var continuouseTextValue: Signal<String?, NoError> {
        return textField.reactive.continuousTextValues
    }
    
    var textFieldReactive: Reactive<UITextField> {
        return textField.reactive
    }
    
    var keyboardType: KeyboardType = .normal {
        didSet {
            changeKeyboard()
        }
    }
    
    var textFieldAccessoryView: UIView? {
        get {
            return textField.inputAccessoryView
        }
        set {
            textField.inputAccessoryView = newValue
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupViews()
    }
    
    private func setupViews() {
        textField = UITextField()
        stackView.addArrangedSubview(textField)
        textField.delegate = self
    }
    
    private func changeKeyboard() {
        switch keyboardType {
        case .normal:
            textField.keyboardType = .default
            textField.textContentType = UITextContentType.init(rawValue: "")
        case .address:
            textField.keyboardType = .default
            textField.textContentType = UITextContentType.fullStreetAddress
        case .url:
            textField.keyboardType = .URL
            textField.textContentType = UITextContentType.URL
        case .tel:
            textField.keyboardType = .phonePad
            textField.textContentType = UITextContentType.telephoneNumber
        }
    }
    
    enum KeyboardType {
        case normal
        case tel
        case address
        case url
    }
}


extension MaterialTextField: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        isInputed = true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        isInputed = !(textField.text?.isEmpty ?? true)
    }
}
