//
//  MaterialTextColorPickerView.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/11.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import ReactiveSwift
import ReactiveCocoa
import Result

class MaterialColorPickerTextField: MaterialContentView {
    
    private var colorPickerTextField: ColorPickerView!
    
    var selectedColor: UIColor {
        return colorPickerTextField.selectedColor
    }
    
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        initViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        initViews()
    }
    
    private func initViews() {
        colorPickerTextField = ColorPickerView()
        
        stackView.addArrangedSubview(colorPickerTextField)
        
        isInputed = true
    }
    
    func select(colorString hexString: String) {
        colorPickerTextField.select(colorString: hexString)
    }

}

