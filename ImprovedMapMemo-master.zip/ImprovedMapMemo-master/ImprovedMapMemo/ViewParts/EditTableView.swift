//
//  EditTableView.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/02/01.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class EditTableView: UITableView {
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.next?.touchesBegan(touches, with: event)
    }
}

