//
//  ColorFilterButton.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/11.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class ColorFilterButton: UIButton {
    
    var buttonColor: UIColor = .black {
        didSet {
            self.borderColor = buttonColor
        }
    }
    
    override var isSelected: Bool {
        didSet {
            self.backgroundColor = isSelected ? self.borderColor : .white
        }
    }
    
    init(buttonColor: UIColor) {
        self.buttonColor = buttonColor
        super.init(frame: CGRect(x: 0, y: 0, width: 40, height: 40))
        setupViews()
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        setupViews()
    }
    
    private func setupViews() {
        self.layer.cornerRadius = self.bounds.height / 2
        self.clipsToBounds = true
        self.borderColor = buttonColor
        self.borderWidth = 4
        self.backgroundColor = .white
        
        NSLayoutConstraint.activate([
            self.widthAnchor.constraint(equalToConstant: 40),
            self.heightAnchor.constraint(equalToConstant: 40)
            ])
        
        self.reactive.controlEvents(.touchUpInside).observeValues { [unowned self] _ in
            self.isSelected.toggle()
        }
    }
}
