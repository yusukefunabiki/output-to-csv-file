//
//  SpacedLabel.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/05.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class SpacedLabel: UILabel {
    
    var sideMargin: CGFloat = 4
    
    override var intrinsicContentSize: CGSize {
        let origin = super.intrinsicContentSize
        return CGSize(width: origin.width + sideMargin * 2 , height: origin.height)
    }
}
