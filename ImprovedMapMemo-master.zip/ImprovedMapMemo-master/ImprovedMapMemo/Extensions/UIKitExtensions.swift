//
//  UIKitExtensions.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/31.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

extension UIView {
    
    @IBInspectable
    var borderColor: UIColor? {
        get {
            return layer.borderColor?.uiColor
        }
        set {
            guard let color = newValue else {
                layer.borderColor = nil
                return
            }
            layer.borderColor = color.cgColor
        }
    }
    
    @IBInspectable
    var borderWidth: CGFloat {
        get {
            return layer.borderWidth
        }
        set {
            layer.borderWidth = newValue
        }
    }
    
    @IBInspectable
    var cornerRadius: CGFloat {
        get {
            return layer.cornerRadius
        }
        set {
            layer.masksToBounds = true
            layer.cornerRadius = abs(CGFloat(Int(newValue * 100)) / 100)
        }
    }
    
    func squashHeightConstraint() {
        let heights = self.constraints.filter { $0.firstAttribute == .height }
        heights.forEach { self.removeConstraint($0) }
        let zeroHeight = NSLayoutConstraint(item: self, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .height, multiplier: 1, constant: 0)
        self.addConstraint(zeroHeight)
        self.isHidden = true
    }
    
}

extension CGColor {
    
    var uiColor: UIColor? {
        return UIColor(cgColor: self)
    }
    
}

extension String {
    
    /**
     16進数からUIColorへ変換する.
     - parameter String: 16進数
     - returns UIColor: RGB
     */
    var uiColor: UIColor {
        
        let hexR = String(self[self.index(self.startIndex, offsetBy: 0)...self.index(self.startIndex, offsetBy: 1)])
        let hexG = String(self[self.index(self.startIndex, offsetBy: 2)...self.index(self.startIndex, offsetBy: 3)])
        let hexB = String(self[self.index(self.startIndex, offsetBy: 4)...self.index(self.startIndex, offsetBy: 5)])
        let hexA = String(self[self.index(self.startIndex, offsetBy: 6)...self.index(self.startIndex, offsetBy: 7)])
        
        let red = CGFloat(Int(hexR, radix: 16)!) / 255
        let green = CGFloat(Int(hexG, radix: 16)!) / 255
        let blue = CGFloat(Int(hexB, radix: 16)!) / 255
        let alpha = CGFloat(Int(hexA, radix: 16)!) / 255
        
        return UIColor(red: red, green: green, blue: blue, alpha: alpha)
    }
}

extension UIColor {
    var hexString: String {
        var r:CGFloat = 0
        var g:CGFloat = 0
        var b:CGFloat = 0
        var a:CGFloat = 0
        
        getRed(&r, green: &g, blue: &b, alpha: &a)
        
        let hexR = String((Int)(r*255), radix: 16)
        let hexG = String((Int)(g*255), radix: 16)
        let hexB = String((Int)(b*255), radix: 16)
        let hexA = String((Int)(a*255), radix: 16)
                
        return "\(hexR)\(hexG)\(hexB)\(hexA)"
        
    }
    
    class var colorList: [UIColor] {
        return [R.color.red()!, R.color.light_red()!, R.color.purple()!,
                R.color.blue()!, R.color.light_blue()!, R.color.green()!,
                R.color.light_green()!, R.color.yellow()!, R.color.orange()!]
    }
}
