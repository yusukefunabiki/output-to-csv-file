//
//  SemiModalViewController.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/02/28.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class SemiModalViewController: UIViewController, OverCurrentTransitionable {
    var percentThreshold: CGFloat = 0.3
    var interactor = OverCurrentTransitioningInteractor()
    
    private var tableViewContentOffsetY: CGFloat = 0.0
    
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var backgroundView: UIView!
    @IBOutlet private weak var containerView: UIView!
    @IBOutlet private weak var headerView: UIView!
    
    @IBOutlet private weak var titleLabel: UILabel!
    
    
    var place: Place! {
        didSet {
            tableViewDataSource = DetailTableViewDataSource(place: place, cellID: R.reuseIdentifier.semiModalViewCell)
        }
    }
    var tableViewDataSource: DetailTableViewDataSource!
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        transitioningDelegate = self
        modalPresentationStyle = .custom
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        transitioningDelegate = self
        modalPresentationStyle = .custom
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        interactor.startHandler = { [weak self] in
            self?.tableView.bounces = false
        }
        
        interactor.resetHandler = { [weak self] in
            self?.tableView.bounces = true
        }
        
        setupViews()
    }
    
    private func setupViews() {
        containerView.layer.maskedCorners = [.layerMinXMinYCorner, .layerMaxXMinYCorner]
        
        let headerGesture = UIPanGestureRecognizer(target: self, action: #selector(headerDidScroll(_:)))
        headerView.addGestureRecognizer(headerGesture)
        
        let tableViewGesture = UIPanGestureRecognizer(target: self, action: #selector(tableViewDidScroll(_:)))
        tableViewGesture.delegate = self
        tableView.addGestureRecognizer(tableViewGesture)
        
        let backgroundGesture = UITapGestureRecognizer(target: self, action: #selector(backgroundDidTap(_:)))
        backgroundView.addGestureRecognizer(backgroundGesture)
        
        tableView.delegate = self
        tableView.dataSource = tableViewDataSource
        
        tableView.tableFooterView = UIView()
        
        titleLabel.text = place.title
    }
    
    @objc private func backgroundDidTap(_ sender: UITapGestureRecognizer) {
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc private func headerDidScroll(_ sender: UIPanGestureRecognizer) {
        interactor.updateStateShouldStartIfNeeded()
        handleTransitionGesture(sender)
    }
    
    @objc private func tableViewDidScroll(_ sender: UIPanGestureRecognizer) {
        if tableViewContentOffsetY <= 0 {
            interactor.updateStateShouldStartIfNeeded()
        }
        interactor.setStartInteractionTranslationY(sender.translation(in: view).y)
        handleTransitionGesture(sender)
    }
    
    @IBAction func editButtonDidTap(_ sender: UIButton) {
        dismiss(animated: true)
        guard let viewController = R.storyboard.registView().instantiateInitialViewController() as? RegistViewController else {
            return
        }
        viewController.place = self.place
        viewController.mode = .edit
        
        let navigationController = UINavigationController(rootViewController: viewController)
        self.presentingViewController?.present(navigationController, animated: true, completion: nil)
        
    }
    
}

extension SemiModalViewController: UITableViewDelegate {
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        tableViewContentOffsetY = scrollView.contentOffset.y
    }
    
}

extension SemiModalViewController: UIGestureRecognizerDelegate {
    func gestureRecognizer(_ gestureRecognizer: UIGestureRecognizer, shouldRecognizeSimultaneouslyWith otherGestureRecognizer: UIGestureRecognizer) -> Bool {
        return true
    }
}

extension SemiModalViewController: UIViewControllerTransitioningDelegate {
    func presentationController(forPresented presented: UIViewController, presenting: UIViewController?, source: UIViewController) -> UIPresentationController? {
        return ModalPresentationController(presentedViewController: presented, presenting: presenting)
    }
    
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        return PullDownDismissAnimator()
    }
    
    func interactionControllerForDismissal(using animator: UIViewControllerAnimatedTransitioning) -> UIViewControllerInteractiveTransitioning? {
        switch interactor.state {
        case .hasStarted, .shouldFinish:
            return interactor
        default:
            return nil
        }
    }
}
