//
//  ViewController.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/29.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import UIKit

class ViewController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        var viewControllers: [UIViewController] = []
        
        if let mapView = R.storyboard.mapView().instantiateInitialViewController() as? MapViewController {
            mapView.tabBarItem = UITabBarItem(title: "map", image: nil, tag: 1)
            viewControllers.append(mapView)
        }
        
        if let listView = R.storyboard.listView().instantiateInitialViewController() {
            listView.tabBarItem = UITabBarItem(title: "list", image: nil, tag: 2)
            viewControllers.append(listView)
        }
        
        self.setViewControllers(viewControllers, animated: false)
        
        self.selectedIndex = 0
    }
    
    override func tabBar(_ tabBar: UITabBar, didSelect item: UITabBarItem) {
        guard let selected = selectedViewController?.tabBarItem,
            selected.isEqual(item) else {
                return
        }
        
        if let mapView = selectedViewController as? MapViewController {
            mapView.deselectAnnotations()
            mapView.setRegionOverView()
        } else if let listView = (selectedViewController as? UINavigationController)?.children.first as? ListViewController {
            listView.scrollToTop()
        }
    }
}

