//
//  ListViewController.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/30.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class ListViewController: UIViewController {
    
    private let manager = PlaceManager.shared
    private var places: [Place] = []
    private var formattedPlaces: [[Place]] {
        var formatted: [[Place]] = []
        UIColor.colorList.forEach { (color) in
            var sameColoredPlaces: [Place] = []
            places.forEach({ (place) in
                if place.color == color.hexString {
                    sameColoredPlaces.append(place)
                }
            })
            if sameColoredPlaces.count > 0 {
                formatted.append(sameColoredPlaces)
            }
        }
        return formatted
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        places = manager.listPlaces()
        
        tableView.reloadData()
    }
    
    func scrollToTop() {
        tableView.scrollToRow(at: IndexPath(row: 0, section: 0), at: UITableView.ScrollPosition.top, animated: true)
    }
}

extension ListViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return formattedPlaces.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return formattedPlaces[section].count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.tableViewCell, for: indexPath)!
        cell.textLabel?.text = formattedPlaces[indexPath.section][indexPath.row].title
        cell.detailTextLabel?.text = formattedPlaces[indexPath.section][indexPath.row].address
        cell.accessibilityIdentifier = formattedPlaces[indexPath.section][indexPath.row].id
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let id = tableView.cellForRow(at: indexPath)?.accessibilityIdentifier,
            let place = manager.fetch(placeID: id) else {
            return
        }
        
        guard let viewController = R.storyboard.detailView().instantiateInitialViewController() as? DetailViewController else {
            return
        }
        viewController.place = place
        self.navigationController?.pushViewController(viewController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        guard editingStyle == .delete else {
            return
        }
        let place = formattedPlaces[indexPath.section][indexPath.row]
        let alert = UIAlertController(title: "Delete Place", message: place.title, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Delete", style: .destructive, handler: { [unowned self] (_) in
            tableView.beginUpdates()
            tableView.deleteRows(at: [indexPath], with: .automatic)
            self.manager.remove(placeID: place.id)
            self.places = self.manager.listPlaces()
            tableView.endUpdates()
        }))
        self.present(alert, animated: true, completion: nil)
    }
    
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let view = SectionHeaderView()
        view.title = "ababa"
        view.tintColor = formattedPlaces[section].first!.color.uiColor
        
        return view
    }
    
}
