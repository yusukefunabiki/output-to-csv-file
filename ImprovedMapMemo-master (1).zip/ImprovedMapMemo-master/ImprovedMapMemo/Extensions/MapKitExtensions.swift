//
//  MapKitExtensions.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/18.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import MapKit
import CoreLocation


extension CLPlacemark {
    var address: String {
        var address = ""
        if let ocean = self.ocean, let location = self.location {
            address.append(ocean)
            address.append(" (\(location.coordinate.location), \(location.coordinate.longitude))")
        } else {
            let components = [self.country, self.administrativeArea, self.locality, self.thoroughfare, self.subThoroughfare]
            address.append(components.compactMap { $0 }.joined(separator: " "))
        }
        return address
    }
}
