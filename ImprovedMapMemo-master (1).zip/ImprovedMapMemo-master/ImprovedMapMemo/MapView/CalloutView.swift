//
//  CalloutView.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/31.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import ReactiveSwift
import ReactiveCocoa

class CalloutView: UIView {
    
    @IBOutlet weak var routeButton: ActionButton!
    @IBOutlet weak var telButton: ActionButton!
    @IBOutlet weak var browserButton: ActionButton!
    @IBOutlet weak var dummyButton: ActionButton!
    @IBOutlet weak var dummyButton2: ActionButton!
    @IBOutlet weak var deleteButton: ActionButton!
    
    
    private var place: Place?
    
    var alertPresenting: ((UIAlertAction) -> Void)?
    
    var isEnableTelButton: Bool {
        get {
            if let tel = place?.tel {
                return !tel.isEmpty
            } else {
                return false
            }
        }
    }
    
    var isEnableBrowserButton: Bool {
        get {
            if let url = place?.url {
                return !url.isEmpty
            } else {
                return false
            }
        }
    }
    
    init(place: Place) {
        super.init(frame: .zero)
        self.place = place
        self.nibInit()
        self.initControll()
    }
    
    override init(frame: CGRect) {

        super.init(frame: frame)
        self.nibInit()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        self.nibInit()
    }
    
    private func nibInit() {
        guard let view = R.nib.calloutView(owner: self) else {
            return
        }
        
        view.frame = self.bounds
        view.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        self.addSubview(view)
        
        initView()
    }
    
    private func initControll() {
        
        guard let place = place else {
            return
        }
        
        routeButton.reactive.controlEvents(.touchUpInside).observeValues { (_) in
            let url = self.makeRouteSearchURL(latitude: place.coodinate.latitude, longitude: place.coodinate.longitude)
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
        
        if let tel = place.tel {
            telButton.reactive.controlEvents(.touchUpInside).observeValues { (_) in
                let url = URL(string: "tel://\(tel)")!
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
        
        if let url = place.url {
            browserButton.reactive.controlEvents(.touchUpInside).observeValues { (_) in
                let url = URL(string: url)!
                UIApplication.shared.open(url, options: [:], completionHandler: nil)
            }
        }
        
        dummyButton.reactive.controlEvents(.touchUpInside).observeValues { (_) in
        }
    }
    
    private func initView() {
        telButton.isEnabled = isEnableTelButton
        browserButton.isEnabled = isEnableBrowserButton
        
        deleteButton.type = .delete
    }


    func makeRouteSearchURL(latitude: Double, longitude: Double) -> URL {
        let daddr = NSString(format: "%f,%f", latitude, longitude)
        let urlString = "http://maps.apple.com/?daddr=\(daddr)&dirflg=d"
        let url = URL(string: urlString)!
        return url
    }
}
