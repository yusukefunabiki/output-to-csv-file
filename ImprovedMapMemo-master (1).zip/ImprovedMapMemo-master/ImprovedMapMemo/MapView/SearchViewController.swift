//
//  PullUpViewController.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/18.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import MapKit
import ReactiveCocoa
import ReactiveSwift
import Result

class SearchViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    @IBOutlet weak var tableView: UITableView!
    
    private var searchedPlaces: [MKMapItem] = []
    
    var shouldOpenView: MutableProperty<Bool> = MutableProperty<Bool>(false)
    
    var selectedPlace: MutableProperty<MKMapItem?> = MutableProperty<MKMapItem?>(nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.layer.maskedCorners = [.layerMaxXMinYCorner, .layerMinXMinYCorner]
        
        searchTextField.delegate = self
        tableView.delegate = self
        tableView.dataSource = self
        
        registObservers()
    }
    
    private func registObservers() {
        searchTextField.reactive.continuousTextValues
            .flatMap(.latest) { (text) -> SignalProducer<[MKMapItem], NoError> in
                guard let text = text else {
                    return SignalProducer(value: [])
                }
                return self.searchPlaces(keyword: text, region: nil).flatMapError { _ in SignalProducer<[MKMapItem], NoError>(value: []) }
            }
            .observeValues { [unowned self] (items) in
                self.searchedPlaces = items
                self.tableView.reloadData()
            }
    }
    
    func searchPlaces(keyword query: String, region: MKCoordinateRegion?) -> SignalProducer<[MKMapItem], AnyError> {
        return SignalProducer<[MKMapItem], AnyError> { observer, lifetime in
            let localSearch = self.searchPlaces(keyword: query, region: nil) { result in
                switch result {
                case .success(let items):
                    observer.send(value: items)
                    observer.sendCompleted()
                case .failure(let error):
                    observer.send(error: AnyError(error))
                }
            }
            
            lifetime.observeEnded {
                localSearch.cancel()
            }
        }
    }
    
    private func searchPlaces(keyword query: String, region: MKCoordinateRegion?, completionHandler: @escaping (Result<[MKMapItem], AnyError>) -> Void ) -> MKLocalSearch {
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        if let region = region {
            request.region = region
        }
        let localSearch = MKLocalSearch(request: request)
        
        localSearch.start { (response, error) in
            if let error = error {
                completionHandler(.failure(AnyError(error)))
                return
            }
            completionHandler(.success(response?.mapItems ?? []))
        }
        
        return localSearch
    }
    
    override func viewDidLayoutSubviews() {
        if view.frame.height == 66 {
            searchTextField.resignFirstResponder()
        }
    }
}

extension SearchViewController: UITextFieldDelegate {
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        shouldOpenView.value = true
    }
}

extension SearchViewController: UITableViewDelegate, UITableViewDataSource {
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return searchedPlaces.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: R.reuseIdentifier.searchedTableViewCell, for: indexPath)!
        cell.textLabel?.text = searchedPlaces[indexPath.row].name
        cell.detailTextLabel?.text = searchedPlaces[indexPath.row].placemark.address
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedPlace.value = searchedPlaces[indexPath.row]
        shouldOpenView.value = false
        searchTextField.resignFirstResponder()
    }


}
