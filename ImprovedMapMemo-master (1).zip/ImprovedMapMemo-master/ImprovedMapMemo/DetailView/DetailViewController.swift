//
//  DetailViewController.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/30.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit
import MapKit

class DetailViewController: UIViewController {
    
    private let manager = PlaceManager.shared
    
    var place: Place! {
        didSet {
            self.title = place.title
            self.navigationController?.navigationBar.tintColor = place.color.uiColor
        }
    }
    var tableViewDataSource: DetailTableViewDataSource!
    
    @IBOutlet private weak var tableView: UITableView!
    @IBOutlet private weak var mapView: MKMapView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .edit,
                                                                 target: self,
                                                                 action: #selector(self.didTapEditButton))
        
        tableViewDataSource = DetailTableViewDataSource(place: place, cellID: R.reuseIdentifier.detailViewCell)
        
        tableView.delegate = self
        tableView.dataSource = tableViewDataSource
        self.title = place.title
        
        let annotation = MKPointAnnotation()
        annotation.coordinate = place.coodinate.coordinate
        mapView.addAnnotation(annotation)
        
        let center = place.coodinate.coordinate
        let span = MKCoordinateSpan(latitudeDelta: 0.5, longitudeDelta: 0.5)
        mapView.setRegion(MKCoordinateRegion(center: center, span: span), animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        place = manager.fetch(placeID: place.id)
        tableViewDataSource.updateItems(of: place)
        tableView.reloadData()
    }
    
    @objc private func didTapEditButton() {
        guard let viewController = R.storyboard.registView().instantiateInitialViewController() as? RegistViewController else {
            return
        }
        viewController.place = place
        viewController.mode = .edit
        
        let navigationController = UINavigationController(rootViewController: viewController)
        self.present(navigationController, animated: true, completion: nil)
    }
}

extension DetailViewController: UITableViewDelegate {

}
