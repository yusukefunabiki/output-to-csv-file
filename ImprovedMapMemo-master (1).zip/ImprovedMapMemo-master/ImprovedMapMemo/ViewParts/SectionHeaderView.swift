//
//  SectionHeaderView.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/15.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class SectionHeaderView: UIView {
    
    @IBOutlet private weak var label: UILabel!
    @IBOutlet private weak var separator: HorizontalSeparator! {
        didSet {
            separator.lineHeight = 1
        }
    }
    
    override var tintColor: UIColor! {
        set {
            separator.lineColor = newValue
        }
        get {
            return separator.lineColor
        }
    }
    
    var title: String? {
        set { label.text = newValue }
        get { return label.text }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        loadNib()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        loadNib()
    }
    
    private func loadNib() {
        let view = R.nib.sectionHeaderView(owner: self)!
        view.frame = self.bounds
        self.addSubview(view)
    }
}
