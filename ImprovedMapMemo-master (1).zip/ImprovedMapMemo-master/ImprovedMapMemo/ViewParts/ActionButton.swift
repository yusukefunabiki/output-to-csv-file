//
//  ActionButton.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/01/31.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class ActionButton: UIButton {
    override func awakeFromNib() {
        super.awakeFromNib()
        initView()
        setUpColors()
    }
    
    private func initView() {
        self.borderWidth = 1
        self.cornerRadius = 4
        self.clipsToBounds = true
    }
    
    var type: ActionButtonType = .normal {
        didSet {
            setUpColors()
        }
    }
    
    override var isEnabled: Bool {
        didSet {
           setUpColors()
        }
    }
    
    private func setUpColors() {
        self.borderColor = isEnabled ? type.borderColor : .lightGray
        self.setTitleColor(isEnabled ? type.textColor : .lightGray, for: .normal)
    }
}

enum ActionButtonType: Int {
    case normal
    case delete
    
    var borderColor: UIColor {
        switch self {
        case .normal:
            return .darkGray
        case .delete:
            return .red
        }
    }
    
    var textColor: UIColor {
        switch self {
        case .normal:
            return .darkGray
        case .delete:
            return .red
        }
    }
}
