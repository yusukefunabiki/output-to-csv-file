//
//  Separator.swift
//  ImprovedMapMemo
//
//  Created by 舩引 優介 on 2019/03/05.
//  Copyright © 2019 舩引 優介. All rights reserved.
//

import Foundation
import UIKit

class HorizontalSeparator: UIView {
    
    var lineHeight: CGFloat = 1 / UIScreen.main.scale
    
    var lineColor: UIColor = R.color.separator()!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        self.bounds.size.height = lineHeight
    }
    
    init(color: UIColor) {
        super.init(frame: .zero)
        lineColor = color
    }
    
    override func draw(_ rect: CGRect) {
        self.backgroundColor = R.color.white()!
        let context = UIGraphicsGetCurrentContext()
        context?.clear(self.frame)
        context?.setStrokeColor(lineColor.cgColor)
        context?.setLineWidth(self.lineHeight)
        context?.move(to: CGPoint(x: 0, y: lineHeight / 2))
        context?.addLine(to: CGPoint(x: self.bounds.size.width, y: lineHeight / 2))
        context?.strokePath()
    }
    
    override var intrinsicContentSize: CGSize {
        return CGSize(width: super.intrinsicContentSize.width, height: self.lineHeight)
    }
}
